Django admin :

username: anmol
passwrd:12345
